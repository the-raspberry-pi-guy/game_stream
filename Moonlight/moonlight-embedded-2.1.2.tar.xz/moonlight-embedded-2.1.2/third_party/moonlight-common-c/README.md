#Moonlight

Moonlight-common-c contains common C code between Moonlight clients, including 
[Moonlight Windows](https://github.com/moonlight-stream/moonlight-windows) and
[Moonlight iOS](https://github.com/moonlight-stream/moonlight-ios).

If you are implementing your own Moonlight game streaming client that can use a C library, you will need the code here.

It implements the actual GameStream protocol.
