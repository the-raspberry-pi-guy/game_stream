#Moonlight

Moonlight-common-c contains common C code between
[Moonlight Windows](https://github.com/moonlight-stream/moonlight-windows) and
[Moonlight iOS](https://github.com/moonlight-stream/moonlight-ios).

It implements the actual GameStream protocol.
