var searchData=
[
  ['statically_20linking_20libevdev',['Statically linking libevdev',['../static_linking.html',1,'']]],
  ['syn_5fdropped_20handling',['SYN_DROPPED handling',['../syn_dropped.html',1,'']]]
];
