var searchData=
[
  ['modifying_20the_20appearance_20or_20capabilities_20of_20the_20device',['Modifying the appearance or capabilities of the device',['../group__kernel.html',1,'']]],
  ['miscellaneous_20helper_20functions',['Miscellaneous helper functions',['../group__misc.html',1,'']]],
  ['multi_2dtouch_20related_20functions',['Multi-touch related functions',['../group__mt.html',1,'']]]
];
